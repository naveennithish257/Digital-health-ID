// ============================================================
// DIGITAL HEALTH ID SYSTEM - BACKEND SERVER
// Node.js + Express + MySQL
// ============================================================

const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const twilio = require('twilio');
const QRCode = require('qrcode');
const AWS = require('aws-sdk');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================
// MIDDLEWARE CONFIGURATION
// ============================================================

// Security
app.use(helmet());
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3001',
    credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate Limiting
const generalLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 1000,
    message: { status: 'error', error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many requests' } }
});

const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10,
    message: { status: 'error', error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many authentication attempts' } }
});

app.use('/api/', generalLimiter);
app.use('/api/auth/', authLimiter);

// ============================================================
// DATABASE CONNECTION
// ============================================================

const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'healthid_user',
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'health_id_system',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};

const pool = mysql.createPool(dbConfig);

// Test database connection
pool.getConnection()
    .then(connection => {
        console.log('✓ Database connected successfully');
        connection.release();
    })
    .catch(err => {
        console.error('✗ Database connection failed:', err);
        process.exit(1);
    });

// ============================================================
// AWS S3 CONFIGURATION (for file storage)
// ============================================================

const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION || 'ap-south-1'
});

const BUCKET_NAME = process.env.AWS_BUCKET_NAME || 'healthid-storage';

// ============================================================
// TWILIO CONFIGURATION (for SMS/OTP)
// ============================================================

const twilioClient = process.env.TWILIO_ACCOUNT_SID ? 
    twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN) : null;

// ============================================================
// EMAIL CONFIGURATION
// ============================================================

const emailTransporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT || 587,
    secure: false,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    }
});

// ============================================================
// FILE UPLOAD CONFIGURATION
// ============================================================

const storage = multer.memoryStorage();
const upload = multer({
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB
    },
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only JPEG, PNG, and PDF allowed.'));
        }
    }
});

// ============================================================
// UTILITY FUNCTIONS
// ============================================================

// Generate Health ID
async function generateHealthId() {
    const year = new Date().getFullYear();
    let healthId;
    let exists = true;

    while (exists) {
        const random = Math.floor(10000 + Math.random() * 90000);
        healthId = `HID-${year}-${random}`;
        
        const [rows] = await pool.query('SELECT health_id FROM patients WHERE health_id = ?', [healthId]);
        exists = rows.length > 0;
    }

    return healthId;
}

// Generate OTP
function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send SMS OTP
async function sendSMSOTP(phoneNumber, otp) {
    if (!twilioClient) {
        console.log('Twilio not configured. OTP:', otp);
        return true;
    }

    try {
        await twilioClient.messages.create({
            body: `Your HealthID OTP is: ${otp}. Valid for 10 minutes.`,
            from: process.env.TWILIO_PHONE_NUMBER,
            to: phoneNumber
        });
        return true;
    } catch (error) {
        console.error('SMS send error:', error);
        return false;
    }
}

// Send Email
async function sendEmail(to, subject, html) {
    try {
        await emailTransporter.sendMail({
            from: process.env.SMTP_FROM || 'noreply@healthid.gov.in',
            to,
            subject,
            html
        });
        return true;
    } catch (error) {
        console.error('Email send error:', error);
        return false;
    }
}

// Upload to S3
async function uploadToS3(file, folder) {
    const fileName = `${folder}/${Date.now()}-${file.originalname}`;
    const params = {
        Bucket: BUCKET_NAME,
        Key: fileName,
        Body: file.buffer,
        ContentType: file.mimetype,
        ACL: 'private'
    };

    try {
        const result = await s3.upload(params).promise();
        return result.Location;
    } catch (error) {
        console.error('S3 upload error:', error);
        throw new Error('File upload failed');
    }
}

// Generate JWT Token
function generateToken(userId, userType) {
    return jwt.sign(
        { userId, userType },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: '1h' }
    );
}

// Verify JWT Token Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({
            status: 'error',
            error: { code: 'UNAUTHORIZED', message: 'Access token required' }
        });
    }

    jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
        if (err) {
            return res.status(403).json({
                status: 'error',
                error: { code: 'FORBIDDEN', message: 'Invalid or expired token' }
            });
        }
        req.user = user;
        next();
    });
}

// Validation Error Handler
function handleValidationErrors(req, res, next) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(422).json({
            status: 'error',
            error: {
                code: 'VALIDATION_ERROR',
                message: 'Invalid request data',
                details: errors.array()
            }
        });
    }
    next();
}

// Log Access
async function logAccess(patientId, accessorId, accessorType, action, resourceType, resourceId, ip) {
    try {
        const logId = crypto.randomUUID();
        await pool.query(
            `INSERT INTO access_logs (log_id, patient_id, accessor_id, accessor_type, action, 
             resource_type, resource_id, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [logId, patientId, accessorId, accessorType, action, resourceType, resourceId, ip]
        );
    } catch (error) {
        console.error('Access logging error:', error);
    }
}

// ============================================================
// AUTHENTICATION ROUTES
// ============================================================

// Patient Registration
app.post('/api/auth/register', [
    body('full_name').notEmpty().trim(),
    body('date_of_birth').isDate(),
    body('gender').isIn(['Male', 'Female', 'Other']),
    body('blood_group').isIn(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']),
    body('phone_number').matches(/^\+[1-9]\d{1,14}$/),
    body('email').optional().isEmail(),
    handleValidationErrors
], async (req, res) => {
    const connection = await pool.getConnection();
    
    try {
        await connection.beginTransaction();

        const {
            full_name, date_of_birth, gender, blood_group, phone_number, email,
            address, city, state, pincode, allergies, chronic_conditions,
            emergency_contact_name, emergency_contact_phone, emergency_contact_relation
        } = req.body;

        // Check if phone already exists
        const [existing] = await connection.query(
            'SELECT phone_number FROM patients WHERE phone_number = ?',
            [phone_number]
        );

        if (existing.length > 0) {
            await connection.rollback();
            return res.status(400).json({
                status: 'error',
                error: { code: 'DUPLICATE_PHONE', message: 'Phone number already registered' }
            });
        }

        // Generate unique Health ID
        const healthId = await generateHealthId();
        const patientId = crypto.randomUUID();

        // Insert patient
        await connection.query(
            `INSERT INTO patients (patient_id, health_id, full_name, date_of_birth, gender, 
             blood_group, phone_number, email, address, city, state, pincode, allergies, 
             chronic_conditions, emergency_contact_name, emergency_contact_phone, 
             emergency_contact_relation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [patientId, healthId, full_name, date_of_birth, gender, blood_group, phone_number,
             email, address, city, state, pincode, allergies, chronic_conditions,
             emergency_contact_name, emergency_contact_phone, emergency_contact_relation]
        );

        // Generate and store OTP
        const otp = generateOTP();
        const otpExpiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
        const authId = crypto.randomUUID();

        await connection.query(
            `INSERT INTO authentication (auth_id, user_id, user_type, phone_number, otp, otp_expiry)
             VALUES (?, ?, 'Patient', ?, ?, ?)`,
            [authId, patientId, phone_number, otp, otpExpiry]
        );

        await connection.commit();

        // Send OTP
        await sendSMSOTP(phone_number, otp);

        // Send welcome email
        if (email) {
            await sendEmail(
                email,
                'Welcome to HealthID',
                `<h2>Welcome to HealthID!</h2>
                 <p>Your Health ID: <strong>${healthId}</strong></p>
                 <p>Your OTP: <strong>${otp}</strong></p>
                 <p>This OTP is valid for 10 minutes.</p>`
            );
        }

        res.status(201).json({
            status: 'success',
            message: 'Registration successful. OTP sent to phone.',
            data: {
                patient_id: patientId,
                health_id: healthId,
                otp_expiry: otpExpiry
            }
        });

    } catch (error) {
        await connection.rollback();
        console.error('Registration error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Registration failed' }
        });
    } finally {
        connection.release();
    }
});

// Send OTP
app.post('/api/auth/send-otp', [
    body('health_id').notEmpty(),
    body('phone_number').matches(/^\+[1-9]\d{1,14}$/),
    handleValidationErrors
], async (req, res) => {
    try {
        const { health_id, phone_number } = req.body;

        // Verify patient exists
        const [patients] = await pool.query(
            'SELECT patient_id, phone_number FROM patients WHERE health_id = ? AND phone_number = ?',
            [health_id, phone_number]
        );

        if (patients.length === 0) {
            return res.status(404).json({
                status: 'error',
                error: { code: 'NOT_FOUND', message: 'Patient not found' }
            });
        }

        const patient = patients[0];

        // Generate OTP
        const otp = generateOTP();
        const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

        // Update or insert authentication record
        await pool.query(
            `INSERT INTO authentication (auth_id, user_id, user_type, phone_number, otp, otp_expiry)
             VALUES (?, ?, 'Patient', ?, ?, ?)
             ON DUPLICATE KEY UPDATE otp = ?, otp_expiry = ?`,
            [crypto.randomUUID(), patient.patient_id, phone_number, otp, otpExpiry, otp, otpExpiry]
        );

        // Send OTP
        await sendSMSOTP(phone_number, otp);

        res.json({
            status: 'success',
            message: 'OTP sent successfully',
            data: {
                otp_expiry: otpExpiry,
                resend_allowed_after: new Date(Date.now() + 1 * 60 * 1000)
            }
        });

    } catch (error) {
        console.error('Send OTP error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Failed to send OTP' }
        });
    }
});

// Verify OTP and Login
app.post('/api/auth/verify-otp', [
    body('health_id').notEmpty(),
    body('otp').isLength({ min: 6, max: 6 }),
    handleValidationErrors
], async (req, res) => {
    try {
        const { health_id, otp } = req.body;

        // Get patient
        const [patients] = await pool.query(
            'SELECT patient_id, health_id, full_name, blood_group, phone_number FROM patients WHERE health_id = ?',
            [health_id]
        );

        if (patients.length === 0) {
            return res.status(404).json({
                status: 'error',
                error: { code: 'NOT_FOUND', message: 'Patient not found' }
            });
        }

        const patient = patients[0];

        // Verify OTP
        const [auth] = await pool.query(
            `SELECT otp, otp_expiry, failed_login_attempts FROM authentication 
             WHERE user_id = ? AND user_type = 'Patient'`,
            [patient.patient_id]
        );

        if (auth.length === 0 || !auth[0].otp) {
            return res.status(400).json({
                status: 'error',
                error: { code: 'OTP_NOT_FOUND', message: 'OTP not generated' }
            });
        }

        const authRecord = auth[0];

        // Check if account is locked
        if (authRecord.failed_login_attempts >= 5) {
            return res.status(403).json({
                status: 'error',
                error: { code: 'ACCOUNT_LOCKED', message: 'Account locked due to multiple failed attempts' }
            });
        }

        // Check OTP expiry
        if (new Date() > new Date(authRecord.otp_expiry)) {
            return res.status(400).json({
                status: 'error',
                error: { code: 'OTP_EXPIRED', message: 'OTP has expired' }
            });
        }

        // Verify OTP
        if (authRecord.otp !== otp) {
            // Increment failed attempts
            await pool.query(
                'UPDATE authentication SET failed_login_attempts = failed_login_attempts + 1 WHERE user_id = ?',
                [patient.patient_id]
            );

            return res.status(400).json({
                status: 'error',
                error: { code: 'INVALID_OTP', message: 'Invalid OTP' }
            });
        }

        // Successful login
        await pool.query(
            `UPDATE authentication SET last_login = NOW(), failed_login_attempts = 0, 
             otp = NULL, otp_expiry = NULL WHERE user_id = ?`,
            [patient.patient_id]
        );

        // Generate tokens
        const accessToken = generateToken(patient.patient_id, 'Patient');
        const refreshToken = jwt.sign(
            { userId: patient.patient_id, userType: 'Patient' },
            process.env.JWT_REFRESH_SECRET || 'refresh-secret',
            { expiresIn: '7d' }
        );

        res.json({
            status: 'success',
            message: 'Login successful',
            data: {
                access_token: accessToken,
                refresh_token: refreshToken,
                token_type: 'Bearer',
                expires_in: 3600,
                user: {
                    patient_id: patient.patient_id,
                    health_id: patient.health_id,
                    full_name: patient.full_name,
                    blood_group: patient.blood_group
                }
            }
        });

    } catch (error) {
        console.error('OTP verification error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Login failed' }
        });
    }
});

// Refresh Token
app.post('/api/auth/refresh', [
    body('refresh_token').notEmpty(),
    handleValidationErrors
], async (req, res) => {
    try {
        const { refresh_token } = req.body;

        jwt.verify(
            refresh_token,
            process.env.JWT_REFRESH_SECRET || 'refresh-secret',
            (err, user) => {
                if (err) {
                    return res.status(403).json({
                        status: 'error',
                        error: { code: 'INVALID_TOKEN', message: 'Invalid refresh token' }
                    });
                }

                const accessToken = generateToken(user.userId, user.userType);

                res.json({
                    status: 'success',
                    data: {
                        access_token: accessToken,
                        expires_in: 3600
                    }
                });
            }
        );

    } catch (error) {
        console.error('Token refresh error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Token refresh failed' }
        });
    }
});

// ============================================================
// PATIENT ROUTES
// ============================================================

// Get Patient Profile
app.get('/api/patients/:health_id', authenticateToken, async (req, res) => {
    try {
        const { health_id } = req.params;

        const [patients] = await pool.query(
            `SELECT patient_id, health_id, full_name, date_of_birth, 
             TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) as age,
             gender, blood_group, phone_number, email, 
             CONCAT_WS(', ', address, city, state, pincode) as address,
             allergies, chronic_conditions, emergency_contact_name,
             emergency_contact_phone, emergency_contact_relation,
             profile_photo_url, created_at, updated_at
             FROM patients WHERE health_id = ? AND is_active = TRUE`,
            [health_id]
        );

        if (patients.length === 0) {
            return res.status(404).json({
                status: 'error',
                error: { code: 'NOT_FOUND', message: 'Patient not found' }
            });
        }

        const patient = patients[0];

        // Log access
        await logAccess(
            patient.patient_id,
            req.user.userId,
            req.user.userType,
            'View',
            'Patient Profile',
            patient.patient_id,
            req.ip
        );

        res.json({
            status: 'success',
            data: {
                ...patient,
                emergency_contact: {
                    name: patient.emergency_contact_name,
                    phone: patient.emergency_contact_phone,
                    relation: patient.emergency_contact_relation
                }
            }
        });

    } catch (error) {
        console.error('Get patient error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch patient profile' }
        });
    }
});

// Get Patient Dashboard
app.get('/api/patients/:health_id/dashboard', authenticateToken, async (req, res) => {
    try {
        const { health_id } = req.params;

        // Get patient info
        const [patients] = await pool.query(
            'SELECT patient_id, health_id, full_name, blood_group FROM patients WHERE health_id = ?',
            [health_id]
        );

        if (patients.length === 0) {
            return res.status(404).json({
                status: 'error',
                error: { code: 'NOT_FOUND', message: 'Patient not found' }
            });
        }

        const patient = patients[0];

        // Get statistics
        const [stats] = await pool.query(
            `SELECT 
                (SELECT COUNT(*) FROM medical_records WHERE patient_id = ?) as total_records,
                (SELECT COUNT(*) FROM prescriptions WHERE patient_id = ? AND prescription_status = 'Active') as active_prescriptions,
                (SELECT COUNT(*) FROM appointments WHERE patient_id = ?) as total_appointments,
                (SELECT COUNT(*) FROM appointments WHERE patient_id = ? AND status = 'Scheduled' AND appointment_date >= CURDATE()) as upcoming_appointments,
                (SELECT COUNT(*) FROM patient_insurance WHERE patient_id = ? AND is_active = TRUE) as insurance_policies`,
            [patient.patient_id, patient.patient_id, patient.patient_id, patient.patient_id, patient.patient_id]
        );

        // Get recent activities
        const [activities] = await pool.query(
            `SELECT 'checkup' as activity_type, record_title as title, 
                    h.hospital_name as hospital, record_date as date, 'Completed' as status
             FROM medical_records mr
             LEFT JOIN hospitals h ON mr.hospital_id = h.hospital_id
             WHERE mr.patient_id = ?
             ORDER BY record_date DESC LIMIT 5`,
            [patient.patient_id]
        );

        // Get upcoming appointments
        const [appointments] = await pool.query(
            `SELECT a.appointment_id, d.full_name as doctor_name, d.specialization,
                    a.appointment_date as date, a.appointment_time as time,
                    h.hospital_name as hospital, a.status
             FROM appointments a
             JOIN doctors d ON a.doctor_id = d.doctor_id
             LEFT JOIN hospitals h ON a.hospital_id = h.hospital_id
             WHERE a.patient_id = ? AND a.appointment_date >= CURDATE() 
             AND a.status IN ('Scheduled', 'Confirmed')
             ORDER BY a.appointment_date, a.appointment_time LIMIT 5`,
            [patient.patient_id]
        );

        res.json({
            status: 'success',
            data: {
                patient_info: patient,
                statistics: stats[0],
                recent_activities: activities,
                upcoming_appointments: appointments
            }
        });

    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch dashboard' }
        });
    }
});

// Update Patient Profile
app.put('/api/patients/:health_id', authenticateToken, [
    body('email').optional().isEmail(),
    body('phone_number').optional().matches(/^\+[1-9]\d{1,14}$/),
    handleValidationErrors
], async (req, res) => {
    try {
        const { health_id } = req.params;
        const updateFields = req.body;

        // Remove fields that shouldn't be updated
        delete updateFields.health_id;
        delete updateFields.patient_id;
        delete updateFields.created_at;

        // Build update query
        const updates = Object.keys(updateFields).map(key => `${key} = ?`).join(', ');
        const values = [...Object.values(updateFields), health_id];

        await pool.query(
            `UPDATE patients SET ${updates}, updated_at = NOW() WHERE health_id = ?`,
            values
        );

        res.json({
            status: 'success',
            message: 'Profile updated successfully'
        });

    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Profile update failed' }
        });
    }
});

// Upload Profile Photo
app.post('/api/patients/:health_id/photo', 
    authenticateToken, 
    upload.single('photo'), 
    async (req, res) => {
    try {
        const { health_id } = req.params;

        if (!req.file) {
            return res.status(400).json({
                status: 'error',
                error: { code: 'NO_FILE', message: 'No file uploaded' }
            });
        }

        // Upload to S3
        const photoUrl = await uploadToS3(req.file, 'photos');

        // Update patient record
        await pool.query(
            'UPDATE patients SET profile_photo_url = ? WHERE health_id = ?',
            [photoUrl, health_id]
        );

        res.json({
            status: 'success',
            message: 'Photo uploaded successfully',
            data: { photo_url: photoUrl }
        });

    } catch (error) {
        console.error('Photo upload error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Photo upload failed' }
        });
    }
});

// ============================================================
// MEDICAL RECORDS ROUTES
// ============================================================

// Get All Medical Records
app.get('/api/patients/:health_id/records', authenticateToken, async (req, res) => {
    try {
        const { health_id } = req.params;
        const { record_type, from_date, to_date, page = 1, limit = 20 } = req.query;

        // Get patient_id
        const [patients] = await pool.query(
            'SELECT patient_id FROM patients WHERE health_id = ?',
            [health_id]
        );

        if (patients.length === 0) {
            return res.status(404).json({
                status: 'error',
                error: { code: 'NOT_FOUND', message: 'Patient not found' }
            });
        }

        const patientId = patients[0].patient_id;

        // Build query
        let query = `SELECT mr.record_id, mr.record_type, mr.record_title, mr.record_date,
                            h.hospital_name, d.full_name as doctor_name, mr.diagnosis,
                            mr.file_url, mr.file_type, mr.file_size_kb, mr.is_critical,
                            mr.created_at
                     FROM medical_records mr
                     LEFT JOIN hospitals h ON mr.hospital_id = h.hospital_id
                     LEFT JOIN doctors d ON mr.doctor_id = d.doctor_id
                     WHERE mr.patient_id = ?`;
        
        const params = [patientId];

        if (record_type) {
            query += ' AND mr.record_type = ?';
            params.push(record_type);
        }

        if (from_date) {
            query += ' AND mr.record_date >= ?';
            params.push(from_date);
        }

        if (to_date) {
            query += ' AND mr.record_date <= ?';
            params.push(to_date);
        }

        query += ' ORDER BY mr.record_date DESC, mr.created_at DESC';

        // Get total count
        const countQuery = query.replace(/SELECT .+ FROM/, 'SELECT COUNT(*) as total FROM');
        const [countResult] = await pool.query(countQuery, params);
        const totalRecords = countResult[0].total;

        // Add pagination
        const offset = (page - 1) * limit;
        query += ' LIMIT ? OFFSET ?';
        params.push(parseInt(limit), offset);

        const [records] = await pool.query(query, params);

        res.json({
            status: 'success',
            data: {
                records,
                pagination: {
                    current_page: parseInt(page),
                    total_pages: Math.ceil(totalRecords / limit),
                    total_records: totalRecords,
                    records_per_page: parseInt(limit)
                }
            }
        });

    } catch (error) {
        console.error('Get records error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch records' }
        });
    }
});

// Upload Medical Record
app.post('/api/patients/:health_id/records',
    authenticateToken,
    upload.single('file'),
    [
        body('record_type').notEmpty(),
        body('record_title').notEmpty(),
        body('record_date').isDate(),
        handleValidationErrors
    ],
    async (req, res) => {
    try {
        const { health_id } = req.params;
        const { record_type, record_title, record_date, hospital_id, doctor_id, diagnosis } = req.body;

        // Get patient_id
        const [patients] = await pool.query(
            'SELECT patient_id FROM patients WHERE health_id = ?',
            [health_id]
        );

        if (patients.length === 0) {
            return res.status(404).json({
                status: 'error',
                error: { code: 'NOT_FOUND', message: 'Patient not found' }
            });
        }

        const patientId = patients[0].patient_id;

        // Upload file to S3
        let fileUrl = null;
        let fileType = null;
        let fileSizeKb = null;

        if (req.file) {
            fileUrl = await uploadToS3(req.file, 'records');
            fileType = req.file.mimetype.split('/')[1].toUpperCase();
            fileSizeKb = Math.round(req.file.size / 1024);
        }

        // Insert record
        const recordId = crypto.randomUUID();
        await pool.query(
            `INSERT INTO medical_records (record_id, patient_id, doctor_id, hospital_id,
             record_type, record_title, record_date, diagnosis, file_url, file_type, file_size_kb)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [recordId, patientId, doctor_id, hospital_id, record_type, record_title, 
             record_date, diagnosis, fileUrl, fileType, fileSizeKb]
        );

        // Create notification
        await pool.query(
            `INSERT INTO notifications (notification_id, user_id, user_type, notification_type,
             title, message, priority)
             VALUES (?, ?, 'Patient', 'Report Ready', 'New Medical Record Added', ?, 'Medium')`,
            [crypto.randomUUID(), patientId, `Your ${record_title} has been uploaded successfully.`]
        );

        res.status(201).json({
            status: 'success',
            message: 'Record uploaded successfully',
            data: {
                record_id: recordId,
                record_title,
                file_url: fileUrl
            }
        });

    } catch (error) {
        console.error('Upload record error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'Record upload failed' }
        });
    }
});

// ============================================================
// EMERGENCY ROUTES
// ============================================================

// Generate Emergency QR Code
app.post('/api/patients/:health_id/emergency/qr-code', authenticateToken, async (req, res) => {
    try {
        const { health_id } = req.params;

        // Get patient info
        const [patients] = await pool.query(
            `SELECT patient_id, health_id, full_name, date_of_birth, gender, blood_group,
                    allergies, chronic_conditions, emergency_contact_name, emergency_contact_phone,
                    emergency_contact_relation
             FROM patients WHERE health_id = ?`,
            [health_id]
        );

        if (patients.length === 0) {
            return res.status(404).json({
                status: 'error',
                error: { code: 'NOT_FOUND', message: 'Patient not found' }
            });
        }

        const patient = patients[0];

        // Get current medications
        const [medications] = await pool.query(
            `SELECT pm.medicine_name, pm.dosage, pm.frequency
             FROM prescription_medications pm
             JOIN prescriptions p ON pm.prescription_id = p.prescription_id
             WHERE p.patient_id = ? AND p.prescription_status = 'Active'`,
            [patient.patient_id]
        );

        // Create encrypted data
        const qrData = {
            health_id: patient.health_id,
            name: patient.full_name,
            dob: patient.date_of_birth,
            blood_group: patient.blood_group,
            allergies: patient.allergies,
            conditions: patient.chronic_conditions,
            medications: medications,
            emergency_contact: {
                name: patient.emergency_contact_name,
                phone: patient.emergency_contact_phone,
                relation: patient.emergency_contact_relation
            },
            generated_at: new Date().toISOString()
        };

        const qrDataString = JSON.stringify(qrData);
        const qrId = crypto.randomUUID();

        // Generate QR code
        const qrImageData = await QRCode.toDataURL(qrDataString);

        // Save QR code info
        const expiresAt = new Date();
        expiresAt.setMonth(expiresAt.getMonth() + 6); // 6 months validity

        await pool.query(
            `INSERT INTO emergency_qr_codes (qr_id, patient_id, qr_code_data, qr_image_url, expires_at)
             VALUES (?, ?, ?, ?, ?)`,
            [qrId, patient.patient_id, qrDataString, qrImageData, expiresAt]
        );

        res.status(201).json({
            status: 'success',
            message: 'Emergency QR code generated',
            data: {
                qr_id: qrId,
                qr_code_data: qrDataString,
                qr_image_url: qrImageData,
                generated_at: new Date(),
                expires_at: expiresAt
            }
        });

    } catch (error) {
        console.error('QR generation error:', error);
        res.status(500).json({
            status: 'error',
            error: { code: 'INTERNAL_ERROR', message: 'QR code generation failed' }
        });
    }
});

// ============================================================
// HEALTH CHECK
// ============================================================

app.get('/api/health', (req, res) => {
    res.json({
        status: 'success',
        message: 'HealthID API is running',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// ============================================================
// ERROR HANDLER
// ============================================================

app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
        status: 'error',
        error: {
            code: 'INTERNAL_ERROR',
            message: err.message || 'Internal server error'
        }
    });
});

// ============================================================
// START SERVER
// ============================================================

app.listen(PORT, () => {
    console.log(`
    ╔════════════════════════════════════════╗
    ║   HealthID API Server                  ║
    ║   Running on port ${PORT}                 ║
    ║   Environment: ${process.env.NODE_ENV || 'development'}          ║
    ╚════════════════════════════════════════╝
    `);
});

module.exports = app;
